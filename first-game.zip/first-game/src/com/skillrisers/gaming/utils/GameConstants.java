package com.skillrisers.gaming.utils;
/*
 * static - Load when class or interface is loaded in the memory so static things load that time.
 	Memory Eager
 */
// interface contract- What to do
public interface GameConstants {
	public static final int BWIDTH = 800;
	int BHEIGHT = 600;
	String GAME_TITLE = "My First Game";
	String GAME_BACKGROUND = "game-bg.jpeg";
}
