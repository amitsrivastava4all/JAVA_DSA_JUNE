package com.skillrisers.gaming.sprites;

public class Enemy {

}
