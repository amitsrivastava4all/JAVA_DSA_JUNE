package com.skillrisers.gaming.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.skillrisers.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
		public Board() {
			setSize(BWIDTH, BHEIGHT);
			setVisible(true);
		}
		
		private void drawBackGround(Graphics g) {
			try {
			BufferedImage img =  ImageIO.read(Board.class.getResource(GAME_BACKGROUND));
			
			g.drawImage(img, 0,0,BWIDTH, BHEIGHT, null);
			System.out.println("After Drawing....");
			}
			catch(Exception err) {
				System.out.println(err);
				g.setColor(Color.RED);
				g.fillRect(0,0, BWIDTH, BHEIGHT);
			}
			
		}
		
		@Override
		public void paintComponent(Graphics g) {
			// super - we call parent things
			super.paintComponent(g);
			drawBackGround(g);
			
		}

}
