package com.skillrisers.gaming.main;

import javax.swing.JFrame;

import com.skillrisers.gaming.utils.GameConstants;

public class GameFrame extends JFrame implements GameConstants {
	
	public GameFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setSize(BWIDTH, BHEIGHT);
		setLocationRelativeTo(null);
		setTitle(GAME_TITLE);
		Board board = new Board();
		getContentPane().add(board);
		setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameFrame obj = new GameFrame();
		

	}

}
