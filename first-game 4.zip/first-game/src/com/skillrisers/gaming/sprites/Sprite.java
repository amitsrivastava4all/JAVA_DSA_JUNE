package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import com.skillrisers.gaming.main.Board;

// Parent class (Common Features)
public abstract class Sprite {
	protected int x;
	protected int y;
	protected int w;
	protected int h;
	ImageIcon img;
	protected int speed;
	//BufferedImage img;
	public Sprite() {
		
	}
	public Sprite(int x, int y, int w , int h, String imageName) throws IOException {
		// img =  ImageIO.read(Sprite.class.getResource(imageName)).;
		img = new ImageIcon(Sprite.class.getResource(imageName));
		this.x = x;
		this.y = y;
		this.h = h;
		this.w = w;
		speed = 3;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	
	
	
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	abstract void move(); // scope is default scope
	
	public void drawSprite(Graphics g) {
		
		
		g.drawImage(img.getImage(), x, y, w, h, null);
	}
	
}
