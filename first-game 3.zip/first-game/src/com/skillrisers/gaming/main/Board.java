package com.skillrisers.gaming.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.skillrisers.gaming.sprites.Enemy;
import com.skillrisers.gaming.sprites.Player;
import com.skillrisers.gaming.utils.GameConstants;


//class M implements ActionListener{
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		
//	}
//}

public class Board extends JPanel implements GameConstants {
		Player player;
		//Enemy enemy;
		ArrayList<Enemy> enemies = new ArrayList<>();
		final int FLOOR;
		BufferedImage img;
		Timer timer;
		String message = "";
		public Board() throws IOException {
			setSize(BWIDTH, BHEIGHT);
			setVisible(true);
			FLOOR = BHEIGHT - 100;
			 img =  ImageIO.read(Board.class.getResource(GAME_BACKGROUND));
			 loadSprites();
			 gameLoop();
			 setFocusable(true);
			 bindEvents();
		}
		
		
		private boolean isCollide(Player player, Enemy enemy) {
			int maxH = player.getH()>enemy.getH()?player.getH(): enemy.getH();
			int maxW = player.getW()>enemy.getW()?player.getW(): enemy.getW();
			
			int distanceX = Math.abs(player.getX() - enemy.getX());
			int distanceY = Math.abs(player.getY() - enemy.getY());
			//System.out.println(distanceX);
			//System.out.println(distanceY);
			//System.out.println(maxW- player.getW());
			//System.out.println(maxH - player.getH());
			return (distanceX<=maxW  && distanceY<=maxH); 
		}
		
		private void checkCollision() {
			for(Enemy e : enemies) {
				if(isCollide(player, e)) {
					gameOver();
				}
			}
		}
		
		private void gameOver() {
			message = "Game Over";
		}
		
		
		
		private void bindEvents() {
			this.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if(e.getKeyCode()== KeyEvent.VK_RIGHT) {
						player.setSpeed(7);
						player.move();
					}
					else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
						player.setSpeed(-7);
						player.move();
					}
					
				}
				@Override
				public void keyReleased(KeyEvent e) {
					player.setSpeed(0);
					//System.out.println("Key Release "+e.getKeyChar()+" Ascii "+e.getKeyCode());
				}
			});
		}
		
		private void gameLoop() {
			//timer = new Timer(GAME_DELAY, new M())
			timer = new Timer(GAME_DELAY, new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					repaint();
					checkCollision();
				}
			});
			timer.start();
		}
		
		private void loadEnemies() throws IOException {
			int ENEMY_X = BWIDTH /2 - 200;
			final int ENEMY_Y = 50;
			final int ENEMY_W = 70;
			final int ENEMY_H = 70;
			int gap = 200;
			int speed = 1;
			for(int i = 0; i<DEFAULT_ENEMIES; i++) {
				Enemy enemy = new Enemy(ENEMY_X, ENEMY_Y, ENEMY_W, ENEMY_H, ENEMY_IMAGE, speed);
				
				enemies.add(enemy);
				ENEMY_X = ENEMY_X + gap;
				speed++;
			}
		}
		
		private void loadSprites() throws IOException {
			final int PLAYER_START_X = 50;
			final int PLAYER_HEIGHT = 70;
			final int PLAYER_Y = FLOOR - PLAYER_HEIGHT;
			player = new Player(PLAYER_START_X, PLAYER_Y, 70, PLAYER_HEIGHT,PLAYER_IMAGE);
		
			// Load Enemy
			loadEnemies();
		}
		
		private void drawBackGround(Graphics g) {
			try {
			
			
			g.drawImage(img, 0,0,BWIDTH, BHEIGHT, null);
			
			}
			catch(Exception err) {
				System.out.println(err);
				g.setColor(Color.RED);
				g.fillRect(0,0, BWIDTH, BHEIGHT);
			}
			
		}
		
		private void drawEnemies(Graphics g) {
			for(Enemy e : enemies) {
				e.drawEnemy(g);
			}
		}
		
		private void printGameOver(Graphics g) {
				if(message.length()>0) {
				g.setColor(Color.RED);
				g.setFont(new Font("times", Font.BOLD, 50));
				g.drawString(message, BWIDTH/2,BHEIGHT/2 );
				}
		}
		
		@Override
		public void paintComponent(Graphics g) {
			// super - we call parent things
			super.paintComponent(g);
			drawBackGround(g);
			player.drawSprite(g);
			drawEnemies(g);
			printGameOver(g);
			
		}

}
