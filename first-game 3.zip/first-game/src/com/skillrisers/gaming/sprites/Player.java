// first line 
package com.skillrisers.gaming.sprites;

import java.io.IOException;

import com.skillrisers.gaming.utils.GameConstants;

public class Player extends Sprite implements GameConstants{
	
	public Player(int x, int y, int w, int h , String imageName) throws IOException{
		super(x, y, w, h, imageName);
		this.speed = 2;
		
	}
	@Override
	public void move() {
		outOfScreen();
		this.x = this.x  + speed;
		
	}
	public void outOfScreen() {
		if(x<=0) {
			speed =2;
		}
		else if (x>=BWIDTH-w) {
			speed = -2;
		}
		
	}
	
}
