package com.skillrisers.gaming.utils;
/*
 * static - Load when class or interface is loaded in the memory so static things load that time.
 	Memory Eager
 */
// interface contract- What to do
public interface GameConstants {
	public static final int BWIDTH = 900;
	int BHEIGHT = 700;
	String GAME_TITLE = "My First Game";
	String GAME_BACKGROUND = "game-bg.jpeg";
	String PLAYER_IMAGE = "player.gif";
	String ENEMY_IMAGE = "spider.gif";
	int GAME_DELAY = 10; // MS
	int DEFAULT_ENEMIES = 3;
	
}
