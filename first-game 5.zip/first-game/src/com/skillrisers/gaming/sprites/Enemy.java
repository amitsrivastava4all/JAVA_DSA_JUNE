package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.io.IOException;

import com.skillrisers.gaming.main.Board;
import com.skillrisers.gaming.utils.GameConstants;

public class Enemy extends Sprite implements GameConstants {
	int direction;
	public Enemy(int x, int y, int w, int h , String imageName, int speed) throws IOException{
		super(x, y, w, h, imageName); // Parent const call
		this.speed = speed;
		direction = TOP_BOTTOM_DIRECTION;
	}
	@Override
	void move() {
		if(direction == TOP_BOTTOM_DIRECTION) {
		y = y + speed;
		}
		else if(direction == RIGHT_LEFT_DIRECTION) {
			outOfScreen();
			x = x + speed;
			
			
		}
		
	}
	
	public void outOfScreen() {
		if(direction == TOP_BOTTOM_DIRECTION ) {
		if(y>=BHEIGHT) {
			y = 0;
			
		}
		}
		else if (direction == RIGHT_LEFT_DIRECTION) {
			if(x<=0) {
				x = BWIDTH-50;
			}
		}
		
		
	}
	
	
	
	
	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	public void drawEnemy(Graphics g) {
		drawSprite(g);
		move();
		outOfScreen();
	}
	
}
