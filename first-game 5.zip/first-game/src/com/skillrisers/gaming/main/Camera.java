package com.skillrisers.gaming.main;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.gaming.main.Board;
import com.skillrisers.gaming.utils.GameConstants;

public class Camera implements GameConstants {
	BufferedImage background;
	int x;
	int y;
	int w;
	int h;

	BufferedImage subImage;
	public Camera () throws IOException {
		x = 0;
		y = 0;
		
		w = BWIDTH;
		h = BHEIGHT;
		background =  ImageIO.read(Camera.class.getResource(GAME_BACKGROUND));
		
	}
	BufferedImage getSubImage(int speed){
		x = x + speed;
		subImage = background.getSubimage(x, y, w, h);
		return subImage;
	}

}
