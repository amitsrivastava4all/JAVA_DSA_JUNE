package com.skillrisers.gaming.main;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.skillrisers.gaming.utils.GameConstants;

public class GameFrame extends JFrame implements GameConstants {
	
	public GameFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setSize(BWIDTH, BHEIGHT);
		setLocationRelativeTo(null);
		setTitle(GAME_TITLE);
		setResizable(false);
		try {
		Board board = new Board();
		
		getContentPane().add(board);
		setVisible(true);
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(this, "OOPS Something went Wrong");
			System.out.println(e);
			e.printStackTrace();
			System.exit(0);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameFrame obj = new GameFrame();
		

	}

}
