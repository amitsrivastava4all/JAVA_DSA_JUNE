package com.skillrisers.gaming.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.skillrisers.gaming.sprites.Enemy;
import com.skillrisers.gaming.sprites.Player;
import com.skillrisers.gaming.utils.GameConstants;


//class M implements ActionListener{
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		
//	}
//}

public class Board extends JPanel implements GameConstants {
		Player player;
		Enemy enemy;
		final int FLOOR;
		BufferedImage img;
		Timer timer;
		public Board() throws IOException {
			setSize(BWIDTH, BHEIGHT);
			setVisible(true);
			FLOOR = BHEIGHT - 100;
			 img =  ImageIO.read(Board.class.getResource(GAME_BACKGROUND));
			 loadSprites();
			 gameLoop();
		}
		
		private void gameLoop() {
			//timer = new Timer(GAME_DELAY, new M())
			timer = new Timer(GAME_DELAY, new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					repaint();
				}
			});
			timer.start();
		}
		
		private void loadSprites() throws IOException {
			final int PLAYER_START_X = 50;
			final int PLAYER_HEIGHT = 70;
			final int PLAYER_Y = FLOOR - PLAYER_HEIGHT;
			player = new Player(PLAYER_START_X, PLAYER_Y, 70, PLAYER_HEIGHT,PLAYER_IMAGE);
		
			// Load Enemy
			final int ENEMY_X = BWIDTH /2;
			final int ENEMY_Y = 50;
			final int ENEMY_W = 70;
			final int ENEMY_H = 70;
			enemy = new Enemy(ENEMY_X, ENEMY_Y, ENEMY_W, ENEMY_H, ENEMY_IMAGE);
		}
		
		private void drawBackGround(Graphics g) {
			try {
			
			
			g.drawImage(img, 0,0,BWIDTH, BHEIGHT, null);
			
			}
			catch(Exception err) {
				System.out.println(err);
				g.setColor(Color.RED);
				g.fillRect(0,0, BWIDTH, BHEIGHT);
			}
			
		}
		
		@Override
		public void paintComponent(Graphics g) {
			// super - we call parent things
			super.paintComponent(g);
			drawBackGround(g);
			player.drawSprite(g);
			enemy.drawEnemy(g);
			
		}

}
