package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.io.IOException;

import com.skillrisers.gaming.utils.GameConstants;

public class Enemy extends Sprite implements GameConstants {
	
	public Enemy(int x, int y, int w, int h , String imageName) throws IOException{
		super(x, y, w, h, imageName);
	}
	@Override
	void move() {
		
		y = y + speed;
		
	}
	
	
	public void drawEnemy(Graphics g) {
		drawSprite(g);
		move();
		outOfScreen();
	}
	void outOfScreen(){
		if(y>=BHEIGHT) {
			y = 0;
			
		}
	}
}
