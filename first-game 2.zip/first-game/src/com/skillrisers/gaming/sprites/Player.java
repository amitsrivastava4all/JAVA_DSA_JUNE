// first line 
package com.skillrisers.gaming.sprites;

import java.io.IOException;

public class Player extends Sprite{
	public Player(int x, int y, int w, int h , String imageName) throws IOException{
		super(x, y, w, h, imageName);
	}
	@Override
	public void move() {
		
	}
}
